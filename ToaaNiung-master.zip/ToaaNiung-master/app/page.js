import LandingPage from './components/Landing';

export default async function Home() {

  return (
      <div>
        <LandingPage />
      </div>
  );
}
